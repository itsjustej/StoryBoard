let scene = 1;
let img_one;
let img_two;
let img_three;
let img_four;
let img_five;
let music;

function preload() {
  img_one = loadImage('crying.jpg');
  img_two = loadImage('rage.jpg');
  img_three = loadImage('black.jpg');
  img_four = loadImage('adult.jpeg');
  img_five = loadImage('kick.jpg');
  music = loadSound('bgmusic.mp3')

}

function setup() {
  createCanvas(windowWidth, windowHeight);
  music.play();
}

function draw() {
  background(0, 0, 91); 

  if (scene === 1) {
    image(img_one, 100, 150);
    fill(0, 178, 255);
    textSize(24);
    textAlign(CENTER);
    text("Gon's friend Kite has died", width/2, 100);
  } else if (scene === 2) {
    image(img_two, 100, 150);
    fill(0, 178, 255);
    textSize(24);
    textAlign(CENTER);
    text("Gon knows the killer - he is infuriated", width/2, 100);
  } else if (scene === 3) {
    image(img_three, 100, 150);
    fill(0, 178, 255);
    textSize(24);
    textAlign(CENTER);
    text("Gon's anger is consuming him", width/2, 100);
  } else if (scene == 4) {
    image(img_four, 175, 100);
    fill(0, 178, 255);
    textSize(24);
    textAlign(LEFT);
    text("Gon was so angry, he aged 30 years", 50, 75);
  } else if (scene == 5) {
    image(img_five, 100, 150);
    fill(0, 178, 255);
    textSize(24);
    textAlign(CENTER);
    text("Gon got his revenge", width/2, 100);
  }
}

function keyPressed() {
  if (keyCode == RIGHT_ARROW) {
    scene++;
    if (scene > 5) {
      scene = 1;
    }
  } else if (keyCode == LEFT_ARROW) {
    scene--;
    if (scene < 1) {
      scene = 5;
    }
  }
}
